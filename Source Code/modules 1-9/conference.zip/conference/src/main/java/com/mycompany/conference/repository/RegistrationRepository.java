package com.mycompany.conference.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mycompany.conference.model.Registration;
import com.mycompany.conference.model.RegistrationReport;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, Long>{

//	Registration save(Registration registration);

//	List<Registration> findAll();

//	List<RegistrationReport> findAllReports();
	
	List<RegistrationReport> registrationReport();

}